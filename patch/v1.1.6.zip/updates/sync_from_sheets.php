<?php
include_once __DIR__ . '/../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = $_POST['nama'] ?? '';
    $tanggal_indo = $_POST['tanggal'] ?? ''; // Format: dd/mm/yyyy
    $status = $_POST['status'] ?? '';

    if (!empty($nama) && !empty($tanggal_indo) && !empty($status)) {
        $conn->select_db("app");

        // 1. Ubah format tanggal dd/mm/yyyy dari Sheets menjadi yyyy-mm-dd untuk MySQL
        $dateParts = explode('/', $tanggal_indo);
        if (count($dateParts) === 3) {
            $tanggal_mysql = $dateParts[2] . '-' . $dateParts[1] . '-' . $dateParts[0];
            
            // 2. Cari NISN siswa berdasarkan namanya
            $stmt_siswa = $conn->prepare("SELECT nisn FROM siswa WHERE nama_siswa = ?");
            $stmt_siswa->bind_param("s", $nama);
            $stmt_siswa->execute();
            $res_siswa = $stmt_siswa->get_result()->fetch_assoc();
            $stmt_siswa->close();

            if ($res_siswa) {
                $nisn = $res_siswa['nisn'];
                
                // 3. Timpa/Update status kehadiran di MySQL lokal
                $stmt_update = $conn->prepare("INSERT INTO presensi (nisn, nama_siswa, tanggal, status, bulan) VALUES (?, ?, ?, ?, '') 
                                               ON DUPLICATE KEY UPDATE status = VALUES(status)");
                $stmt_update->bind_param("ssss", $nisn, $nama, $tanggal_mysql, $status);
                $stmt_update->execute();
                $stmt_update->close();
                
                echo "Sync Sukses";
            } else {
                echo "Nama siswa tidak cocok di lokal";
            }
        }
    }
}