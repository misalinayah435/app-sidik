<?php
include_once __DIR__ . '/config/database.php';
include_once __DIR__ . '/config/apps_script.php';

// Fitur Pencarian
$search = isset($_GET['q']) ? $conn->real_escape_string($_GET['q']) : '';
$query = "SELECT * FROM siswa";
if ($search) {
    $query .= " WHERE nama_siswa LIKE '%$search%' OR nisn LIKE '%$search%' OR nis LIKE '%$search%'";
}
$query .= " ORDER BY nama_siswa ASC";

$res = $conn->query($query);
$data_siswa = ($res && $res->num_rows > 0) ? $res->fetch_all(MYSQLI_ASSOC) : [];

// Statistik (Tetap dihitung dari total database tanpa filter pencarian untuk dashboard)
$stat_res = $conn->query("SELECT 
    COUNT(*) as total, 
    SUM(CASE WHEN jenis_kelamin IN ('L', 'Laki-laki') THEN 1 ELSE 0 END) as laki,
    SUM(CASE WHEN jenis_kelamin IN ('P', 'Perempuan') THEN 1 ELSE 0 END) as peremp 
    FROM siswa");
$stats = $stat_res->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EduManage SaaS</title>
    <link rel="icon" type="image/png" href="assets/logo.png">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #fcfcfd; }
        .hide-scrollbar::-webkit-scrollbar { display: none; }
        .hide-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
    </style>
</head>
<body class="text-slate-900 antialiased">

    <nav class="bg-white/80 backdrop-blur-md border-b border-slate-100 sticky top-0 z-50 px-6 h-16 flex items-center justify-between">
        <div class="flex items-center gap-3">
            <img src="assets/logo.png" alt="Logo" class="w-7 h-7">
            <span class="text-sm font-bold tracking-tight">MIS AL INAYAH</span>
        </div>
        <a href="updates/sync_data.php" class="text-[10px] font-bold bg-slate-900 text-white px-4 py-2 rounded-lg hover:bg-indigo-600 transition-all uppercase tracking-widest">Sync</a>
    </nav>

    <main class="max-w-7xl mx-auto px-6 py-8">
        
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8">
            <div>
                <h1 class="text-2xl font-bold">Data Induk Murid</h1>
                <p class="text-xs text-slate-500 font-medium mt-1">Grade 6B • Tahun 2025/2026</p>
            </div>
            
            <form action="" method="GET" class="relative w-full md:w-80">
                <input type="text" name="q" value="<?= htmlspecialchars($search) ?>" placeholder="Cari Nama/NISN..." 
                    class="w-full bg-white border border-slate-200 rounded-xl py-2.5 pl-10 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all">
                <svg class="w-4 h-4 absolute left-3 top-3 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
            </form>
        </div>

        <div class="flex md:grid md:grid-cols-3 gap-4 mb-8 overflow-x-auto hide-scrollbar pb-2">
            <div class="min-w-[140px] flex-1 bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex items-center gap-4">
                <div class="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-600">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                </div>
                <div>
                    <p class="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Total</p>
                    <h3 class="text-lg font-bold"><?= $stats['total'] ?></h3>
                </div>
            </div>
            <div class="min-w-[140px] flex-1 bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex items-center gap-4">
                <div class="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>
                </div>
                <div>
                    <p class="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Laki-laki</p>
                    <h3 class="text-lg font-bold"><?= $stats['laki'] ?></h3>
                </div>
            </div>
            <div class="min-w-[140px] flex-1 bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex items-center gap-4">
                <div class="w-10 h-10 rounded-xl bg-rose-50 flex items-center justify-center text-rose-600">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>
                </div>
                <div>
                    <p class="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Perempuan</p>
                    <h3 class="text-lg font-bold"><?= $stats['peremp'] ?></h3>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="bg-slate-50/50 border-b border-slate-100 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-center">
                            <th class="p-4">No</th>
                            <th class="p-4">NIS</th>
                            <th class="p-4">NISN</th>
                            <th class="p-4 text-left">Nama Murid</th>
                            <th class="p-4">JK</th>
                            <th class="p-4">Tempat Lahir</th>
                            <th class="p-4">Tanggal Lahir</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-50">
                        <?php if (!empty($data_siswa)): $n=1; foreach ($data_siswa as $s): ?>
                        <tr class="hover:bg-slate-50/50 transition-colors text-xs">
                            <td class="p-4 text-center text-slate-400 font-medium"><?= $n++ ?></td>
                            <td class="p-4 text-center text-slate-600"><?= $s['nis'] ?></td>
                            <td class="p-4 text-center font-semibold text-slate-900"><?= $s['nisn'] ?></td>
                            <td class="p-4 font-bold text-slate-800 uppercase tracking-tight"><?= $s['nama_siswa'] ?></td>
                            <td class="p-4 text-center">
                                <?php $isL = (strtoupper($s['jenis_kelamin'][0]) == 'L'); ?>
                                <span class="px-2 py-0.5 rounded-md text-[9px] font-bold border <?= $isL ? 'bg-blue-50 border-blue-100 text-blue-600' : 'bg-rose-50 border-rose-100 text-rose-600' ?>">
                                    <?= $isL ? 'L' : 'P' ?>
                                </span>
                            </td>
                            <td class="p-4 text-slate-600 text-center"><?= $s['tempat_lahir'] ?></td>
                            <td class="p-4 text-slate-600 text-center"><?= date('d/m/Y', strtotime($s['tanggal_lahir'])) ?></td>
                        </tr>
                        <?php endforeach; else: ?>
                        <tr><td colspan="7" class="p-10 text-center text-slate-400 italic">Data tidak ditemukan.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

</body>
</html>