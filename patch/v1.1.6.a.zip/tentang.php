<?php
include_once __DIR__ . '/config/database.php';
include_once __DIR__ . '/includes/header.php';

// Ambil tanggal modifikasi file untuk info rilis real-time
$waktu_rilis = date('d F Y H:i', filemtime(__DIR__ . '/includes/header.php'));
?>

<main class="max-w-4xl mx-auto px-6 py-12 text-left">
    <div class="mb-10 border-b border-slate-100 pb-6">
        <h1 class="text-3xl font-black tracking-tighter uppercase text-slate-950">Tentang Aplikasi</h1>
        <p class="text-[10px] text-indigo-600 font-extrabold uppercase tracking-[0.2em] mt-1">Sistem Manajemen Informasi Akademik Terintegrasi</p>
    </div>

    <div class="bg-white border border-slate-100 shadow-xl rounded-2xl p-6 md:p-8 mb-8 flex flex-col md:flex-row items-center gap-6">
        <div class="w-20 h-20 bg-indigo-50 rounded-2xl flex items-center justify-center p-4 border border-indigo-100/50 shadow-sm shrink-0">
            <img src="assets/logo.png" alt="EduManage Logo" class="w-full h-full object-contain">
        </div>
        <div class="text-center md:text-left">
            <h2 class="text-xl font-bold text-slate-900 leading-tight">EduManage SaaS</h2>
            <p class="text-xs text-slate-400 font-medium mt-1">Aplikasi khusus pengelolaan administrasi nilai, profil data siswa, dan presensi harian Kelas 6B MIS Al Inayah.</p>
            <div class="mt-4 flex flex-wrap gap-2 justify-center md:justify-start items-center">
                <span class="bg-slate-900 text-white font-mono text-[10px] px-2.5 py-1 rounded-md font-bold tracking-tight">Version <?= APP_VERSION ?></span>
                <span class="bg-emerald-50 text-emerald-700 font-sans text-[10px] px-2.5 py-1 rounded-md font-bold uppercase tracking-wider border border-emerald-100">Production Ready</span>
                <span class="bg-blue-50 text-blue-700 font-sans text-[10px] px-2.5 py-1 rounded-md font-bold uppercase tracking-wider border border-blue-100">Lokal & Cloud Sync</span>
            </div>
            <p class="text-[10px] text-slate-400 font-semibold uppercase mt-3 tracking-wider"><i class="ri-time-line mr-1"></i> Build Rilis Otomatis: <?= $waktu_rilis ?></p>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <div class="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm">
            <div class="w-8 h-8 bg-indigo-50 rounded-lg flex items-center justify-center text-indigo-600 mb-4">
                <i class="ri-cpu-line text-lg"></i>
            </div>
            <h3 class="text-sm font-bold text-slate-900 uppercase tracking-tight mb-2">Teknologi Inti</h3>
            <p class="text-xs text-slate-500 leading-relaxed">
                Dibangun menggunakan core PHP murni dengan database MySQL lokal di Laragon, dikombinasikan dengan framework **Tailwind CSS** untuk antarmuka yang modern, responsif, dan elegan.
            </p>
        </div>

        <div class="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm">
            <div class="w-8 h-8 bg-amber-50 rounded-lg flex items-center justify-center text-amber-600 mb-4">
                <i class="ri-refresh-line text-lg"></i>
            </div>
            <h3 class="text-sm font-bold text-slate-900 uppercase tracking-tight mb-2">Sinkronisasi Dua Arah</h3>
            <p class="text-xs text-slate-500 leading-relaxed">
                Dilengkapi dengan gerbang **Webhook API** dan **Google Apps Script** murni untuk menjamin keakuratan pertukaran data presensi secara real-time dari Web ke Google Sheets maupun sebaliknya.
            </p>
        </div>
    </div>

    <div class="bg-slate-50 border border-slate-100 rounded-2xl p-6 text-slate-500">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xxs font-bold uppercase tracking-wider">
            <div class="flex items-center gap-2">
                <i class="ri-shield-user-line text-base text-slate-400"></i>
                <span>Hak Cipta © 2026 MIS Al Inayah</span>
            </div>
            <div class="flex items-center gap-2 text-slate-400">
                <span>Dikembangkan untuk Efisiensi Madrasah</span>
            </div>
        </div>
    </div>
</main>

<?php include_once __DIR__ . '/includes/footer.php'; ?>