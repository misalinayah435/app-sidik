<?php
// OTOMATISASI VERSI: Membaca waktu modifikasi file header ini (Menggunakan fungsi yang benar: file_exists)
// Jika file diubah, nomor versi otomatis di belakang (build number) akan naik sendiri
$base_version = "1.5"; // Versi Mayor & Minor utama aplikasi Bapak
$last_modified = file_exists(__FILE__) ? filemtime(__FILE__) : time();
$build_number = date('md.Hi', $last_modified); // Format: BulanHari.JamMenit (Contoh: 0516.0914)

if (!defined('APP_VERSION')) {
    define('APP_VERSION', $base_version . '.' . $build_number);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EduManage SaaS v<?= APP_VERSION ?></title>
    <link rel="icon" type="image/png" href="assets/logo.png">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #fcfcfd; }
        .hide-scrollbar::-webkit-scrollbar { display: none; }
        .hide-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        .modal-overlay { background: rgba(15, 23, 42, 0.4); backdrop-filter: blur(4px); transition: all 0.3s; }
        .nav-link-active { color: #4f46e5 !important; border-bottom: 2px solid #4f46e5; }
    </style>
</head>
<body class="text-slate-900 antialiased">

    <nav class="bg-white/80 backdrop-blur-md border-b border-slate-100 sticky top-0 z-50 px-4 h-16 flex items-center justify-between">
        <div class="flex items-center gap-3 border-r border-slate-100 pr-4">
            <img src="assets/logo.png" alt="Logo" class="w-7 h-7">
            <span class="text-[11px] font-black tracking-tighter uppercase leading-none">MIS AL<br>INAYAH</span>
        </div>

        <div class="flex-1 px-4 overflow-x-auto hide-scrollbar">
            <div class="flex items-center gap-6 text-[10px] font-bold uppercase tracking-widest min-w-max h-16">
                <a href="index.php" class="flex items-center h-full <?= basename($_SERVER['PHP_SELF']) == 'index.php' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-slate-400' ?> hover:text-indigo-600 transition-all tracking-[0.2em]">Dashboard</a>
                <a href="siswa.php" class="flex items-center h-full <?= basename($_SERVER['PHP_SELF']) == 'siswa.php' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-slate-400' ?> hover:text-indigo-600 transition-all tracking-[0.2em]">Data Siswa</a>
                <a href="presensi.php" class="flex items-center h-full <?= basename($_SERVER['PHP_SELF']) == 'presensi.php' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-slate-400' ?> hover:text-indigo-600 transition-all tracking-[0.2em]">Presensi</a>
                <a href="nilai.php" class="flex items-center h-full <?= basename($_SERVER['PHP_SELF']) == 'nilai.php' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-slate-400' ?> hover:text-indigo-600 transition-all tracking-[0.2em]">Input Nilai</a>
                <a href="tentang.php" class="flex items-center h-full <?= basename($_SERVER['PHP_SELF']) == 'tentang.php' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-slate-400' ?> hover:text-indigo-600 transition-all tracking-[0.2em]">Tentang</a>
            </div>
        </div>
        
        <div class="flex items-center gap-3">
            <a href="verifikasi.php" class="relative p-2 text-slate-400 hover:text-indigo-600 transition">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                <?php 
                if (isset($conn)) {
                    $pending = $conn->query("SELECT id_pengajuan FROM pengajuan_edit WHERE status='pending'")->num_rows;
                    if($pending > 0): ?>
                        <span class="absolute top-1 right-1 w-2 h-2 bg-rose-500 rounded-full border border-white"></span>
                    <?php endif; 
                }
                ?>
            </a>
            <a href="updates/sync_data.php" class="text-[9px] font-bold bg-slate-900 text-white px-3 py-2 rounded-lg hover:bg-indigo-600 transition-all uppercase tracking-widest italic">Sync</a>
        </div>
    </nav>