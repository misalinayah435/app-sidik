<?php
include_once __DIR__ . '/config/database.php';

// 1. Ambil Statistik Dasar Siswa
$stat_res = $conn->query("SELECT COUNT(*) as total, 
    SUM(CASE WHEN jenis_kelamin IN ('L', 'Laki-laki') THEN 1 ELSE 0 END) as laki,
    SUM(CASE WHEN jenis_kelamin IN ('P', 'Perempuan') THEN 1 ELSE 0 END) as peremp 
    FROM siswa");
$stats = $stat_res->fetch_assoc();

// 2. Ambil Statistik Presensi Hari Ini
date_default_timezone_set('Asia/Jakarta');
$tgl_sekarang = date('Y-m-d');

$presensi_res = $conn->query("SELECT 
    SUM(CASE WHEN status = 'Hadir' THEN 1 ELSE 0 END) as hadir,
    SUM(CASE WHEN status = 'Sakit' THEN 1 ELSE 0 END) as sakit,
    SUM(CASE WHEN status = 'Izin' THEN 1 ELSE 0 END) as izin,
    SUM(CASE WHEN status = 'Alpa' THEN 1 ELSE 0 END) as alpa
    FROM presensi WHERE tanggal = '$tgl_sekarang'");
$presensi_stat = $presensi_res->fetch_assoc();

// 3. Ambil Daftar Murid Tidak Hadir Hari Ini
$tidak_hadir_res = $conn->query("SELECT nama_siswa, status 
    FROM presensi 
    WHERE tanggal = '$tgl_sekarang' AND status IN ('Sakit', 'Izin', 'Alpa')
    ORDER BY status ASC");

include_once __DIR__ . '/includes/header.php';
?>

<main class="max-w-7xl mx-auto px-6 py-12">
    <div class="mb-10 text-left">
        <h1 class="text-3xl font-black tracking-tighter uppercase">Dashboard Utama</h1>
        <p class="text-[10px] text-slate-500 font-bold mt-1 uppercase tracking-[0.2em]">Ringkasan Data & Presensi Grade 6B</p>
    </div>

    <?php include_once __DIR__ . '/includes/stats.php'; ?>

    <div class="mt-12 mb-6 text-left">
        <h2 class="text-lg font-black uppercase tracking-tight">Rekap Presensi Hari Ini</h2>
        <p class="text-[10px] text-slate-400 font-bold uppercase tracking-widest"><?= date('d F Y'); ?></p>
    </div>

    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <?php 
        $p_cards = [
            ['Hadir', $presensi_stat['hadir'] ?? 0, 'bg-emerald-50 text-emerald-600'],
            ['Sakit', $presensi_stat['sakit'] ?? 0, 'bg-amber-50 text-amber-600'],
            ['Izin', $presensi_stat['izin'] ?? 0, 'bg-blue-50 text-blue-600'],
            ['Alpa', $presensi_stat['alpa'] ?? 0, 'bg-rose-50 text-rose-600']
        ];
        foreach($p_cards as $pc): ?>
        <div class="<?= $pc[2] ?> p-5 rounded-2xl border border-white shadow-sm">
            <span class="text-2xl font-black block"><?= $pc[1] ?></span>
            <p class="text-[9px] font-bold uppercase tracking-widest opacity-80 mt-1"><?= $pc[0] ?></p>
        </div>
        <?php endforeach; ?>
    </div>

    <div class="bg-white rounded-2xl border border-slate-100 shadow-xl overflow-hidden">
        <div class="p-5 border-b border-slate-50 bg-slate-50/50">
            <h3 class="text-[10px] font-black uppercase tracking-widest text-slate-500">Daftar Murid Absen / Berhalangan</h3>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-left">
                <thead>
                    <tr class="text-[9px] font-bold text-slate-400 uppercase tracking-widest border-b border-slate-50">
                        <th class="p-4 w-12 text-center">No</th>
                        <th class="p-4">Nama Murid</th>
                        <th class="p-4 text-center">Keterangan</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-50">
                    <?php if ($tidak_hadir_res->num_rows > 0): $n=1; ?>
                        <?php while($th = $tidak_hadir_res->fetch_assoc()): ?>
                        <tr class="hover:bg-slate-50 transition-colors">
                            <td class="p-4 text-center text-xs font-bold text-slate-300"><?= $n++ ?></td>
                            <td class="p-4 text-xs font-bold text-slate-700 uppercase"><?= $th['nama_siswa'] ?></td>
                            <td class="p-4 text-center">
                                <?php 
                                    $badge = 'bg-slate-100 text-slate-500';
                                    if($th['status'] == 'Sakit') $badge = 'bg-amber-100 text-amber-600';
                                    if($th['status'] == 'Izin') $badge = 'bg-blue-100 text-blue-600';
                                    if($th['status'] == 'Alpa') $badge = 'bg-rose-100 text-rose-600';
                                ?>
                                <span class="<?= $badge ?> px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-tighter">
                                    <?= $th['status'] ?>
                                </span>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="3" class="p-10 text-center text-slate-400 text-xs italic">
                                Alhamdulillah, semua murid hadir hari ini.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="mt-12 flex flex-wrap gap-4">
        <a href="siswa.php" class="bg-indigo-600 text-white px-8 py-4 rounded-2xl font-bold text-[10px] uppercase tracking-[0.2em] shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition-all">
            Buka Tabel Data Siswa →
        </a>
        <a href="presensi.php" class="bg-slate-900 text-white px-8 py-4 rounded-2xl font-bold text-[10px] uppercase tracking-[0.2em] shadow-xl shadow-slate-200 hover:bg-black transition-all">
            Input Presensi Baru →
        </a>
    </div>
</main>

<?php include_once __DIR__ . '/includes/footer.php'; ?>